from dynatrace_extension import Extension, Status, StatusValue
import requests
from prometheus_client.parser import text_string_to_metric_families
import requests

class ExtensionImpl(Extension):


    def send_metric_http(self, name, value, dimensions):
        try:
            # Dynatrace API endpoint
            url = f"https://192.168.1.252/e/83cffb45-e7fa-47c5-9f86-c3888ea9b93f/api/v2/metrics/ingest"

            # Token fixo por enquanto — depois movemos para config
            headers = {
                "Authorization": "Api-Token dt0c01.3PUVFCMZNESMB4YWLJ4J42UK.YXGWIYX6OZMYZ5UNUULGWWSJGQGU47KCMUY7MATEVHCNOGT7HO5OLRJ4TNGQZWKE",
                "Content-Type": "text/plain"
            }

            # Format exactly like Dynatrace expects
            dim_str = ",".join([f"{k}={v}" for k, v in dimensions.items()])
            body = f"{name},{dim_str} {value}"

            self.logger.info(f"📤 [HTTP SEND] {body}")

            r = requests.post(url, headers=headers, data=body, verify=False, timeout=10)
            self.logger.info(f"📤 [HTTP SEND] Response {r.status_code}: {r.text}")

        except Exception as e:
            self.logger.error(f"❌ [HTTP ERROR] Failed to send metric via API: {e}")


    def fastcheck(self) -> Status:
        """
        Fastcheck runs BEFORE initialize().
        We cannot use attributes here — only raw activation config.
        """
        self.logger.info("🔍 [FASTCHECK] Running fastcheck...")

        try:
            cfg = self.get_activation_config()
            url = cfg.get("metricsUrl")
            custom_device = cfg.get("customDeviceId")

            if not url or not custom_device:
                msg = "Missing required fields metricsUrl or customDeviceId"
                self.logger.error(f"❌ [FASTCHECK] {msg}")
                return Status(StatusValue.FAILED, msg)

            if not (url.startswith("http://") or url.startswith("https://")):
                msg = f"Invalid URL format: {url}"
                self.logger.error(f"❌ [FASTCHECK] {msg}")
                return Status(StatusValue.FAILED, msg)

            self.logger.info("✅ [FASTCHECK] OK")
            return Status(StatusValue.OK, "OK")

        except Exception as e:
            msg = f"Fastcheck failed: {e}"
            self.logger.error(f"❌ [FASTCHECK] {msg}")
            return Status(StatusValue.FAILED, msg)

    def initialize(self):
        self.logger.info("🔧 [INIT] Initializing extension...")

        cfg = self.get_activation_config()
        self.logger.debug(f"Raw activation config: {cfg}")

        self.metrics_url = cfg.get("metricsUrl")
        self.custom_device_id = cfg.get("customDeviceId")
        self.interval_seconds = int(cfg.get("intervalSeconds", 60))

        raw_filter = cfg.get("metricsFilter") or ""
        self.metrics_filter = {m.strip() for m in raw_filter.split(",") if m.strip()}

        self.logger.info(f"Metrics URL: {self.metrics_url}")
        self.logger.info(f"Custom Device ID: {self.custom_device_id}")
        self.logger.info(f"Interval: {self.interval_seconds}")
        self.logger.info(
            f"Metrics filter: {self.metrics_filter if self.metrics_filter else '<ALL>'}"
        )

        # Schedule collector
        self.logger.info("⏳ Scheduling collector...")
        self.schedule(self.collect_metrics, self.interval_seconds)

    def query(self):
        # Unused default method
        self.logger.debug("ℹ️ query() ignored.")
        return

    def collect_metrics(self):
        self.logger.info("📡 [COLLECT] Collector triggered")
        self.logger.debug(f"Fetching metrics from: {self.metrics_url}")

        try:
            resp = requests.get(self.metrics_url, timeout=10, verify=False)
            resp.raise_for_status()
        except Exception as e:
            self.logger.error(f"❌ Fetch failed: {e}")
            return

        try:
            families = list(text_string_to_metric_families(resp.text))
        except Exception as e:
            self.logger.error(f"❌ Parsing failed: {e}")
            return

        count = 0

        for family in families:
            for sample in family.samples:
                name, labels, value = sample.name, sample.labels, sample.value

                if self.metrics_filter and name not in self.metrics_filter:
                    continue

                dimensions = dict(labels)
                dimensions["dt.entity.custom_device"] = self.custom_device_id
                dimensions["source_url"] = self.metrics_url

                try:
                    self.report_metric(
                        key=name,
                        value=float(value),
                        dimensions=dimensions
                    )
                    count += 1
                except Exception as e:
                    self.logger.error(f"❌ Failed sending metric {name}: {e}")

        self.logger.info(f"✅ Sent {count} samples")


def main():
    ExtensionImpl().run()


if __name__ == "__main__":
    main()
